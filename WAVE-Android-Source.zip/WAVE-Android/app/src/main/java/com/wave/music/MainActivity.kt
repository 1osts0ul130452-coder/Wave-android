package com.wave.music

import android.content.Intent
import android.net.Uri
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import androidx.media3.common.util.UnstableApi
import com.google.common.util.concurrent.MoreExecutors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

private data class Track(val title: String, val artist: String, val preview: String, val artwork: String = "")

class MainActivity : ComponentActivity() {
    @OptIn(UnstableApi::class)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        startService(Intent(this, PlaybackService::class.java))
        setContent { WaveApp() }
    }
}

@OptIn(ExperimentalMaterial3Api::class, UnstableApi::class)
@Composable
private fun WaveApp() {
    val context = LocalContext.current
    var tab by remember { mutableStateOf("Главная") }
    var query by remember { mutableStateOf("") }
    var results by remember { mutableStateOf<List<Track>>(emptyList()) }
    var status by remember { mutableStateOf("Ищи музыку или добавляй аудиофайлы с телефона") }
    var current by remember { mutableStateOf<Track?>(null) }
    var player by remember { mutableStateOf<MediaController?>(null) }
    val favorites = remember { mutableStateListOf<String>() }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        uri?.let {
            context.contentResolver.takePersistableUriPermission(it, Intent.FLAG_GRANT_READ_URI_PERMISSION)
            val track = Track(it.lastPathSegment ?: "Локальный трек", "Файлы телефона", it.toString())
            results = listOf(track) + results
            status = "Добавлен локальный аудиофайл"
        }
    }
    LaunchedEffect(Unit) {
        val token = SessionToken(context, android.content.ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({ player = future.get() }, MoreExecutors.directExecutor())
    }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Color(0xFFB69CFF), secondary = Color(0xFF8E72D8),
        background = Color(0xFF101014), surface = Color(0xFF1B1B22)
    )) {
        Scaffold(
            containerColor = Color(0xFF101014),
            bottomBar = {
                NavigationBar(containerColor = Color(0xFF191920)) {
                    listOf("Главная", "Поиск", "Коллекция").forEach { label ->
                        NavigationBarItem(selected = tab == label, onClick = { tab = label },
                            icon = { Icon(when(label) { "Поиск" -> Icons.Default.Search; "Коллекция" -> Icons.Default.LibraryMusic; else -> Icons.Default.Home }, null) },
                            label = { Text(label) })
                    }
                }
            }
        ) { padding ->
            Column(Modifier.fillMaxSize().padding(padding).padding(horizontal = 18.dp)) {
                Spacer(Modifier.height(18.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text("WAVE", fontSize = 30.sp, fontWeight = FontWeight.Black,
                        color = Color.White, modifier = Modifier.weight(1f))
                    Text("♫", fontSize = 30.sp, color = Color(0xFFB69CFF))
                }
                Text("Твоя музыка. Твои правила.", color = Color.LightGray, fontSize = 13.sp)
                Spacer(Modifier.height(20.dp))
                when (tab) {
                    "Поиск" -> {
                        OutlinedTextField(value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            placeholder = { Text("Трек или исполнитель") },
                            trailingIcon = { IconButton(onClick = {
                                status = "Ищем в открытом каталоге Apple Music…"
                            }) { Icon(Icons.Default.Search, null) } })
                        Button(onClick = {
                            status = "Загружаем результаты…"
                        }, modifier = Modifier.fillMaxWidth()) { Text("Найти") }
                        LaunchedEffect(query, tab) {
                            if (query.length >= 2) {
                                val found = searchCatalog(query)
                                results = found
                                status = if (found.isEmpty()) "Ничего не найдено или нет доступных превью" else "Найдено: ${found.size}. Доступны короткие превью."
                            }
                        }
                    }
                    "Коллекция" -> {
                        Text("Твоя коллекция", color = Color.White, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(12.dp))
                        Button(onClick = { picker.launch(arrayOf("audio/*")) }, modifier = Modifier.fillMaxWidth()) {
                            Icon(Icons.Default.Add, null); Spacer(Modifier.width(8.dp)); Text("Добавить музыку с телефона")
                        }
                        Text("Понравившиеся: ${favorites.size}", color = Color.LightGray)
                    }
                    else -> {
                        Box(Modifier.fillMaxWidth().height(150.dp)
                            .background(Brush.linearGradient(listOf(Color(0xFF503B85), Color(0xFF191923))), RoundedCornerShape(24.dp))
                            .padding(18.dp), contentAlignment = Alignment.BottomStart) {
                            Column {
                                Text("ТВОЯ ВОЛНА", color = Color.White.copy(alpha = .7f), fontSize = 12.sp)
                                Text("Музыка под настроение", color = Color.White, fontSize = 23.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                        Spacer(Modifier.height(20.dp))
                        Text("Найди новые треки", color = Color.White, fontSize = 20.sp, fontWeight = FontWeight.Bold)
                        Spacer(Modifier.height(6.dp))
                        Text("Каталог с поиском и короткими ознакомительными фрагментами.", color = Color.LightGray)
                        Spacer(Modifier.height(12.dp))
                        OutlinedTextField(value = query, onValueChange = { query = it },
                            modifier = Modifier.fillMaxWidth(), singleLine = true,
                            placeholder = { Text("Поиск музыки") },
                            trailingIcon = { Icon(Icons.Default.Search, null) })
                        LaunchedEffect(query) {
                            if (query.length >= 2) {
                                results = searchCatalog(query)
                                status = if (results.isEmpty()) "Нет результатов" else "Найдено ${results.size} треков"
                            }
                        }
                    }
                }
                Spacer(Modifier.height(12.dp))
                Text(status, color = Color(0xFFB9B4C8), fontSize = 12.sp)
                LazyColumn(Modifier.weight(1f)) {
                    items(results) { track ->
                        Row(Modifier.fillMaxWidth().clickable {
                            current = track
                            player?.setMediaItem(MediaItem.fromUri(track.preview))
                            player?.prepare()
                            player?.play()
                        }.padding(vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(48.dp).background(Color(0xFF302943), RoundedCornerShape(10.dp)), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.MusicNote, null, tint = Color(0xFFD0BFFF))
                            }
                            Column(Modifier.weight(1f).padding(horizontal = 12.dp)) {
                                Text(track.title, color = Color.White, fontWeight = FontWeight.SemiBold)
                                Text(track.artist, color = Color.LightGray, fontSize = 12.sp)
                            }
                            IconButton(onClick = { if (track.title !in favorites) favorites.add(track.title) else favorites.remove(track.title) }) {
                                Icon(if (track.title in favorites) Icons.Default.Favorite else Icons.Default.FavoriteBorder, null,
                                    tint = Color(0xFFB69CFF))
                            }
                        }
                        HorizontalDivider(color = Color.DarkGray)
                    }
                }
                current?.let { track ->
                    Surface(color = Color(0xFF25222F), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
                        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(track.title, color = Color.White, fontWeight = FontWeight.Bold)
                                Text(track.artist, color = Color.LightGray, fontSize = 12.sp)
                            }
                            IconButton(onClick = { if (player?.isPlaying == true) player?.pause() else player?.play() }) {
                                Icon(if (player?.isPlaying == true) Icons.Default.Pause else Icons.Default.PlayArrow, null, tint = Color.White)
                            }
                        }
                    }
                }
            }
        }
    }
}

private suspend fun searchCatalog(term: String): List<Track> = withContext(Dispatchers.IO) {
    try {
        val encoded = URLEncoder.encode(term, "UTF-8")
        val request = Request.Builder().url("https://itunes.apple.com/search?term=$encoded&entity=song&limit=25").build()
        OkHttpClient().newCall(request).execute().use { response ->
            if (!response.isSuccessful) return@withContext emptyList()
            val json = JSONObject(response.body!!.string())
            val array = json.getJSONArray("results")
            (0 until array.length()).mapNotNull { i ->
                val item = array.getJSONObject(i)
                val preview = item.optString("previewUrl")
                if (preview.isBlank() || preview == "null") null else Track(
                    item.optString("trackName", "Без названия"),
                    item.optString("artistName", "Неизвестный артист"),
                    preview,
                    item.optString("artworkUrl100", "")
                )
            }
        }
    } catch (_: Exception) { emptyList() }
}
